using System;

class Pessoa 
{
	string Nome;
	int Idade;
	int Peso;
	double Altura;

	public void Envelhecer(int I)
	{
		if (I > Idade)
		{
			Idade = I;
		}
		else 
		{
			Console.WriteLine("Não envelheceu ");
		}
		if (I < 21)
		{
			Altura = ((I - Idade) * 0.5) + Altura;
		}
	}
	public void Engordou(int P)
	{
		if (Peso < P)
		{
			Peso = P;
		}
	}
	public void Emagrecer(int M)
	{
		if (Peso >= M)
		{
			Peso = M;
		}
	}
	public void Crescer(double T)
	{
		if (Altura < T)
		{
			Altura = T;
		}
	}
}